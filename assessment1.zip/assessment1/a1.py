# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 17:50:42 2020

@author: computer
"""

import csv
with open('cm.csv')as csv_file:
    csv_reader=csv.reader(csv_file,delimiter=',')
    line_count=0
   
    for row in csv_reader:
        if line_count ==0:
           print(f'{", ".join(row)}')
           line_count += 1
        else:
           print(f'{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\t{row[4]}\t{row[5]}\t{row[6]}\t{row[7]}\t{row[8]}\t{row[10]}')
           line_count += 1
           
        
